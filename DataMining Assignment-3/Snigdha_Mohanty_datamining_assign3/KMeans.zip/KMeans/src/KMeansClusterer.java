import java.io.File;
import java.util.Iterator;

import net.sf.javaml.clustering.KMeans;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.Instance;
import net.sf.javaml.tools.data.FileHandler;


public class KMeansClusterer {

	
	File f;
	int k;
	
	public KMeansClusterer(File f,int k){
		this.f = f;
		this.k = k;
	}
	
	
	public void runCluster()throws Exception{
		Dataset ds = FileHandler.loadDataset(f, 0, ",");
		
		System.out.println(ds);
		
		KMeans km = new KMeans(k,500);
		
		Dataset[] clustersArr = km.cluster(ds);
		
		int i = 1;
		
		for (Dataset dataset : clustersArr) {
			System.out.println("Cluster "+ i);
			
			Iterator<Instance> iter = dataset.iterator();
			
			while(iter.hasNext()){
				Instance instance = iter.next();
				System.out.println(instance);
			}
			
			i++;
		}
		
	}
	
}
