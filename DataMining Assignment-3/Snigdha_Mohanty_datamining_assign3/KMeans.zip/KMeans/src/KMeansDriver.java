import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import net.sf.javaml.clustering.KMeans;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.Instance;
import net.sf.javaml.tools.data.FileHandler;




public class KMeansDriver {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		String fileName = args[0];
		
		int k = Integer.parseInt(args[1]);
				
		KMeansClusterer km = new KMeansClusterer(new File(fileName), k);
		km.runCluster();
		
		
	}

}
