To compile:

1) Be sure have the files HW1data.txt, Kmeans.java, DataPoints.java and CentroPoints situated in the same directory.
2) Upload the files into an Eclipse Project or any other IDE so as to compile and run.

This Project was done using Eclipse - Juno Service Release 2 on a Mac running 10.9.2