package naivebayes;

public class ContinuousAttribute {

  private double value;

  public ContinuousAttribute(double value) {
    this.value = value;
  }

  public double getValue() {
    return value;
  }
}

