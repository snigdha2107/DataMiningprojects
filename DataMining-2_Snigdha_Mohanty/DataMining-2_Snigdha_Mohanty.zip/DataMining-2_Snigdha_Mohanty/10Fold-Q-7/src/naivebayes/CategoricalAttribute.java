package naivebayes;

public class CategoricalAttribute {

  private String value;

  public CategoricalAttribute(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}

